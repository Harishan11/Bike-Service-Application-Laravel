<?php $__env->startSection('title'); ?>
    Orders
<?php $__env->stopSection(); ?>
<?php $__env->startSection('m-content'); ?>
    <!-- Content wrapper -->
    <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1">
            <div class="row">
                <div class="col-md-12">
                    <!-- All Cars -->
                    <div class="card">
                        <h5 class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h2 class="text-primary">All Orders</h2>
                            </div>
                        </h5>
                        <div class="table-responsive text-nowrap">
                            <div id="carTableDiv">
                                <table class="table table-striped" id="CarTable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Car</th>
                                            
                                            <th>Type</th>
                                            <th>Price</th>
                                            <th>Color</th>
                                            <th>Status</th>
                                            <th>Created</th>
                                        </tr>
                                    </thead>
                                    <?php if(count($orders) > 0): ?>
                                        <tbody class="table-border-bottom-0">
                                            <?php
                                                $count = 1;
                                            ?>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($count++); ?></td>
                                                    <td><?php echo e($order->carName); ?></td>
                                                    
                                                    <td><?php echo e($order->type); ?></td>
                                                    <td><?php echo e($order->price); ?></td>
                                                    <td><?php echo e($order->color); ?></td>
                                                    <td>
                                                        <?php if($order->status == 'complete'): ?>
                                                            <span class="badge rounded-pill bg-success">Complete</span>
                                                        <?php else: ?>
                                                            <span class="badge rounded-pill bg-danger">Incomplete</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($order->created_at)->diffForHumans()); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td colspan="2" class="text-center">
                                                    <span class="badge rounded-pill bg-primary">Totall :
                                                        <?php echo e($orders->sum('price')); ?> $</span>
                                                </td>
                                                <td colspan="2" class="text-center">
                                                    <span class="badge rounded-pill bg-danger">Incomplete :
                                                        <?php echo e($orderIncomplete->sum('price')); ?> $</span>
                                                </td>
                                                <td colspan="2" class="text-center">
                                                    <span class="badge rounded-pill bg-success">Complete :
                                                        <?php echo e($orders->sum('price') - $orderIncomplete->sum('price')); ?>

                                                        $</span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                            <div class="col-12 mt-3 text-center">
                                <button type="button" class="btn btn-primary rounded-0" id="printOrders">
                                    <span class="tf-icons bx bx-printer"></span>&nbsp; Print
                                </button>
                            </div>
                        </div>
                        <div class="card-footer">
                            <?php echo e($orders->links()); ?>

                        </div>
                    </div>
                    <!-- All Users -->
                </div>
            </div>
        </div>
        <!-- / Content -->
    </div>
    <!-- Content wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#printOrders').click(function() {
                var mywindow = window.open('', 'PRINT', 'height=400,width=600');
                mywindow.document.write('<html><head><title> Orders </title>');
                mywindow.document.write('</head><body >');
                mywindow.document.write('<h1>Orders</h1>');
                mywindow.document.write(document.getElementById('carTableDiv').innerHTML);
                mywindow.document.write('</body></html>');
                mywindow.document.close(); // necessary for IE >= 10
                mywindow.focus(); // necessary for IE >= 10*/
                mywindow.print();
                mywindow.close();
                return true;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appCustomer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikeservice\resources\views/orders/index.blade.php ENDPATH**/ ?>