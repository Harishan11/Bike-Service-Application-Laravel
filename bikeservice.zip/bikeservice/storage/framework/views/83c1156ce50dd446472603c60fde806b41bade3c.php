<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('m-content'); ?>
    <div class="row">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-xl-4">
                <div class="card  shadow-lg mb-5  rounded">
                    <img class="card-img-top" src="<?php echo e(asset('users/cars/' . $car->picture)); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($car->name); ?></h5>
                        <p class="card-text"><?php echo e($car->description); ?></p>
                        <p class="card-text text-capitalize"><?php echo e($car->color); ?> | <?php echo e($car->type); ?> | <span
                                class="text-danger"><?php echo e($car->price); ?>$</span></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <p class="card-text">
                                <small class="text-muted">Last updated <?php echo e($car->updated_at->diffforhumans()); ?></small>
                            </p>
                            <a href="<?php echo e(route('order-create', ['id' => $car->id])); ?>"
                                class="btn rounded-pill btn-icon btn-primary">
                                <span class="tf-icons bx bxs-cart-add"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    <style>
        .card:hover {
            padding: 20px !important;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appCustomer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikeservice\resources\views/homeCustomer.blade.php ENDPATH**/ ?>