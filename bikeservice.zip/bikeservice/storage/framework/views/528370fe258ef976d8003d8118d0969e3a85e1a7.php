<?php $__env->startSection('title'); ?>
    404 Error
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-light  min-vh-100 d-flex align-items-center justify-content-center">
        <div class="col-8 p-5">
            <img class="img-fluid mb-3" src="<?php echo e(asset('assets/img/illustrations/404.svg')); ?>" alt="404">
        </div>
        <div class="col-4">
            <h3 class="text-danger fw-blod">You do not have permissions on this page...!</h3>
            <a href="<?php echo e(url('/home')); ?>" class="btn shadow-none rounded-0 btn-danger">Go To Home</a>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikeservice\resources\views/errors/404.blade.php ENDPATH**/ ?>