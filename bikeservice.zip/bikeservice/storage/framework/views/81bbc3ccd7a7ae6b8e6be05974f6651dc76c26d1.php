 <!DOCTYPE html>

 <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="light-style" dir="ltr"
     data-theme="theme-default" data-assets-path="<?php echo e(asset('assets')); ?>" data-template="vertical-menu-template-free">

 <head>
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <meta charset="utf-8" />
     <meta name="viewport"
         content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

     <title>Service</title>

     <meta name="description" content="" />

     <!-- Favicon -->
     <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon/favicon.ico')); ?>" />

     <!-- Fonts -->
     <link rel="preconnect" href="https://fonts.googleapis.com" />
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
     <link
         href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
         rel="stylesheet" />

     <!-- Icons. Uncomment required icon fonts -->
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/boxicons.css')); ?>" />

     <!-- Core CSS -->
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/core.css')); ?>" class="template-customizer-core-css" />
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/theme-default.css')); ?>"
         class="template-customizer-theme-css" />
     <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>" />

     <!-- Vendors CSS -->
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
     <!--fontawesome-->
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fontawesome/css/all.min.css')); ?>">
     <!--sweetalert2-->
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/sweetalert2/sweetalert2.min.css')); ?>" />
     <!--jquery-->
     <script src="<?php echo e(asset('assets/js/ajax_jquery.js')); ?>"></script>
     <!--Toastr-->
     <link rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">
     <!-- Page CSS -->
     <?php echo $__env->yieldContent('styles'); ?>
     <!-- Helpers -->
     <script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
 </head>

 <body>
     <!-- Content -->

     <?php echo $__env->yieldContent('content'); ?>

     <!-- / Content -->
     </div>
     <!-- Core JS -->
     <!-- build:js assets/vendor/js/core.js -->
     <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

     <script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>
     <!-- endbuild -->

     <!-- Vendors JS -->

     <!-- Main JS -->
     <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

     <!--Toastr-->
     <script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
     <!--sweetalert2-->
     <!--fontawesome-->
     <script src="<?php echo e(asset('assets/vendor/fontawesome/js/all.min.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/sweetalert2/sweetalert2.min.js')); ?>"></script>
     <!-- Page JS -->
     <?php echo $__env->yieldContent('scripts'); ?>
 </body>

 </html>
<?php /**PATH C:\xampp\htdocs\bikeservice\resources\views/layouts/app.blade.php ENDPATH**/ ?>